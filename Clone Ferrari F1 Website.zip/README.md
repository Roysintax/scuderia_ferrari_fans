
  # Clone Ferrari F1 Website

  This is a code bundle for Clone Ferrari F1 Website. The original project is available at https://www.figma.com/design/SZAO7iQt66XYPJfKu3RCQi/Clone-Ferrari-F1-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  